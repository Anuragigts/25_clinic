DROP TABLE %db_prefix%visit_img;
