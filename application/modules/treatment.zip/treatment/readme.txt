version 0.0.1
Requires Chikitsa 0.1.7

0.0.1
1. Maintain list of treatments with its price list
2. Add treatments in Bill and Visit
